package com.example.cadastrousuario;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TelaEntrar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_entrar);
    }
}