package com.example.cadastrousuario;

public class Usuario {
    public String username;
    public String email;

    public Usuario(String username, String email) {
        this.username = username;
        this.email = email;
    }
}
